library(estimate)
estimateScore(input.ds = "input.gct",
              output.ds="Result.gct", 
              platform="affymetrix")